Calculator unit test example in Java
===============

This project is demo for article for beginners about unit testing http://stokito.blogspot.com/2013/02/blog-post_27.html (sorry, currently only in Russian).

You should use Maven to build project.
Also I would like to recommend you edit code Intellij Idea.
